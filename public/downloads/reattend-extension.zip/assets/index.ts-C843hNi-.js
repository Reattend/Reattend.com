(function(){const y=["nav","header","footer","aside",'[role="navigation"]','[role="banner"]','[role="contentinfo"]','[class*="sidebar"]','[class*="Sidebar"]','[class*="nav-"]','[class*="Nav-"]','[class*="footer"]','[class*="Footer"]','[class*="header"]','[class*="Header"]','[class*="ad-"]','[class*="Ad-"]','[class*="advertisement"]','[id*="ad-"]','[id*="sidebar"]',"script","style","noscript","iframe",'[aria-hidden="true"]',".cookie-banner",".cookie-consent",'[class*="popup"]','[class*="modal"]','[class*="toolbar"]','[class*="Toolbar"]','[class*="menu-"]','[class*="Menu-"]'],S=["article","main",'[role="main"]','[class*="content"]','[class*="Content"]','[class*="article"]','[class*="Article"]','[class*="post-body"]','[class*="entry-content"]',".message-body",".msg-body","[data-message-id]"];function C(e){const s=(e.textContent||"").trim().split(/\s+/).filter(i=>i.length>2).length,n=e.children.length||1;return s/n}function z(){for(const o of S){const r=document.querySelectorAll(o);if(r.length>0){const a=[];if(r.forEach(c=>{var v;if(y.some(L=>c.closest(L)))return;const u=(v=c.innerText)==null?void 0:v.trim();u&&u.split(/\s+/).length>10&&a.push(u)}),a.length>0){const c=a.join(`

`);return f(c)}}}const e=document.body;if(!e)return"";const t=e.cloneNode(!0);y.forEach(o=>{t.querySelectorAll(o).forEach(r=>r.remove())});const s=t.querySelectorAll("div, section, td");let n=null,i=0;return s.forEach(o=>{if((o.innerText||"").trim().split(/\s+/).filter(b=>b.length>2).length<15)return;const c=C(o);c>i&&(i=c,n=o)}),f(n?n.innerText||"":t.innerText||"")}function f(e){const t=e.split(`
`),s=[];for(const o of t){const r=o.trim();if(!r||r.length<5||!r.includes(" ")&&r.length<20)continue;const a=(r.match(/[a-zA-Z]/g)||[]).length;r.length>0&&a/r.length<.35||(r.match(/[$€£]/g)||[]).length>=2||/^(file|edit|view|window|help|format|insert|tools|debug|terminal|go|run|selection)$/i.test(r)||s.push(r)}const n=s.join(`
`).trim();return n.split(/\s+/).filter(o=>o.length>2).length<15?"":n.slice(0,3e3)}const M=15,B=1e4,x=new WeakMap,w=new WeakMap,E=new WeakSet;function A(e){return e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement?e.value:e.innerText||e.textContent||""}function I(e,t){if(!e)return t;const s=new Set(e.split(`
`).map(o=>o.trim()).filter(o=>o.length>0));return t.split(`
`).map(o=>o.trim()).filter(o=>o.length>0).filter(o=>!s.has(o)).join(`
`)}function _(e){const t=w.get(e);t&&clearTimeout(t);const s=setTimeout(()=>{const n=A(e),i=x.get(e)||"",o=I(i,n);o.split(/\s+/).filter(a=>a.length>2).length>=M&&chrome.runtime.sendMessage({type:"CAPTURE_WRITING",text:o.slice(0,3e3),url:window.location.href,title:document.title}),x.set(e,n)},B);w.set(e,s)}function m(e){E.has(e)||(E.add(e),x.set(e,A(e)),e.addEventListener("input",()=>_(e),{passive:!0}))}const D=["textarea",'input[type="text"]','input[type="email"]','input[type="search"]','[contenteditable="true"]','[contenteditable=""]','[role="textbox"]','[g_editable="true"]','[data-qa="message_input"]'],h=D.join(", ");function R(){document.querySelectorAll(h).forEach(m),new MutationObserver(t=>{for(const s of t)for(const n of s.addedNodes)n instanceof Element&&(n.matches(h)&&m(n),n.querySelectorAll(h).forEach(m))}).observe(document.body,{childList:!0,subtree:!0})}let l=null,d=null;const F={decision:"#D97706",meeting:"#2563EB",idea:"#9333EA",insight:"#059669",context:"#6B7280",tasklike:"#E11D48",note:"#4F46E5"};function N(e,t){const s=e.slice(0,5).map(n=>{const i=F[n.type]||"#6B7280";return`
      <div style="display:flex;align-items:flex-start;gap:8px;padding:6px 0;cursor:pointer" class="ra-memory" data-id="${n.id}">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${i}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:2px">
          <path d="M9.5 2A5.5 5.5 0 0 1 15 7.5V8h1a3 3 0 0 1 3 3v1a2 2 0 0 1-2 2h-1v3a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3v-3H5a2 2 0 0 1-2-2v-1a3 3 0 0 1 3-3h1v-.5A5.5 5.5 0 0 1 9.5 2z"/>
        </svg>
        <div style="flex:1;min-width:0">
          <div style="font-size:12px;font-weight:600;color:#1F2937;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${g(n.title)}</div>
          ${n.summary?`<div style="font-size:11px;color:#6B7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${g(n.summary)}</div>`:""}
        </div>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:2px">
          <polyline points="9 18 15 12 9 6"/>
        </svg>
      </div>
    `}).join("");return`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; margin: 0; padding: 0; }
      .ra-container {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 320px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        z-index: 2147483647;
        animation: ra-slide-in 0.3s ease-out;
      }
      @keyframes ra-slide-in {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .ra-card {
        background: rgba(255,255,255,0.97);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-radius: 16px;
        border: 1px solid #E5E7EB;
        box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25), 0 0 0 1px rgba(0,0,0,0.05);
        overflow: hidden;
      }
      .ra-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 14px;
        background: rgba(79,70,229,0.05);
        border-bottom: 1px solid rgba(79,70,229,0.1);
      }
      .ra-header-left {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .ra-header-title {
        font-size: 11px;
        font-weight: 600;
        color: #4F46E5;
      }
      .ra-close {
        background: none;
        border: none;
        color: #9CA3AF;
        cursor: pointer;
        padding: 2px;
        border-radius: 4px;
        display: flex;
        align-items: center;
      }
      .ra-close:hover { color: #4B5563; }
      .ra-context {
        padding: 6px 14px;
        background: rgba(249,250,251,0.8);
        font-size: 11px;
        color: #6B7280;
        font-style: italic;
      }
      .ra-memories {
        padding: 8px 14px;
        max-height: 160px;
        overflow-y: auto;
      }
      .ra-memory:hover { background: rgba(249,250,251,0.8); border-radius: 8px; }
      .ra-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 14px;
        border-top: 1px solid #F3F4F6;
      }
      .ra-snooze-group {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .ra-snooze-btn {
        background: none;
        border: none;
        font-size: 10px;
        color: #9CA3AF;
        cursor: pointer;
        padding: 2px 4px;
        border-radius: 4px;
      }
      .ra-snooze-btn:hover { color: #4B5563; }
      .ra-snooze-sep { color: #D1D5DB; font-size: 10px; }
      .ra-open-btn {
        background: none;
        border: none;
        font-size: 11px;
        color: #9CA3AF;
        cursor: pointer;
        padding: 2px 4px;
      }
      .ra-open-btn:hover { color: #4F46E5; }
    </style>
    <div class="ra-container">
      <div class="ra-card">
        <div class="ra-header">
          <div class="ra-header-left">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4F46E5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
            </svg>
            <span class="ra-header-title">Related memories found</span>
          </div>
          <button class="ra-close" id="ra-close-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        ${t?`<div class="ra-context">${g(t)}</div>`:""}
        <div class="ra-memories">${s}</div>
        <div class="ra-footer">
          <div class="ra-snooze-group">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
            <button class="ra-snooze-btn" data-minutes="30">Snooze 30m</button>
            <span class="ra-snooze-sep">|</span>
            <button class="ra-snooze-btn" data-minutes="120">2h</button>
            <span class="ra-snooze-sep">|</span>
            <button class="ra-snooze-btn" data-minutes="480">8h</button>
          </div>
          <button class="ra-open-btn" id="ra-open-reattend">Open in Reattend →</button>
        </div>
      </div>
    </div>
  `}function g(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function p(){var e;if(d&&clearTimeout(d),l){const t=(e=l.shadowRoot)==null?void 0:e.querySelector(".ra-container");t&&(t.style.opacity="0",t.style.transform="translateY(10px)",t.style.transition="all 0.3s ease-out"),setTimeout(()=>{l==null||l.remove(),l=null},300)}}function O(e,t){var i,o;l&&(l.remove(),l=null),d&&clearTimeout(d);const s=document.createElement("div");s.id="reattend-ambient-root";const n=s.attachShadow({mode:"closed"});n.innerHTML=N(e,t),document.body.appendChild(s),l=s,(i=n.getElementById("ra-close-btn"))==null||i.addEventListener("click",p),n.querySelectorAll(".ra-snooze-btn").forEach(r=>{r.addEventListener("click",()=>{const a=parseInt(r.dataset.minutes||"30",10);chrome.runtime.sendMessage({type:"SNOOZE_AMBIENT",minutes:a}),p()})}),n.querySelectorAll(".ra-memory").forEach(r=>{r.addEventListener("click",()=>{const a=r.dataset.id;a&&window.open(`https://reattend.com/app/memories/${a}`,"_blank")})}),(o=n.getElementById("ra-open-reattend"))==null||o.addEventListener("click",()=>{window.open("https://reattend.com/app/memories","_blank"),p()}),d=setTimeout(p,3e4)}const j=3e4,H=5e3;let k="";function P(e){let t=0;for(let s=0;s<e.length;s++){const n=e.charCodeAt(s);t=(t<<5)-t+n,t|=0}return t.toString(36)}chrome.runtime.onMessage.addListener(e=>{e.type==="AMBIENT_RESULT"&&e.memories.length>0&&O(e.memories,e.context)});function T(){try{const e=z();if(!e)return;const t=P(e);if(t===k)return;k=t,chrome.runtime.sendMessage({type:"CAPTURE_PAGE",text:e,url:window.location.href,title:document.title})}catch{}}function $(){setTimeout(()=>{T(),setInterval(T,j)},H),R()}window===window.top&&$();
})()
